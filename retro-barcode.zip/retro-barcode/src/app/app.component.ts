import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    title = 'Retro Barcode Generator'
    colorArray = [];

  fillColorArray() {
    for (let y = 0; y < 35; y++) {
      const randNum = (Math.floor(Math.random() * 5) ) + 1;
      if (randNum === 1) {
        this.colorArray.push('#99D9FF');
      } else if (randNum === 2) {
        this.colorArray.push('#2E5166');
      } else if (randNum === 3) {
        this.colorArray.push('#D2897D');
      } else if (randNum === 4) {
        this.colorArray.push('#FF999C');
      } else if (randNum === 5) {
        this.colorArray.push('#8ECCC2');
      }
    }
  }

  ngOnInit() {
    this.fillColorArray();
  }

}
