// require express
var session = require('express-session');
var express = require("express");

var path = require("path");
// create the express app
var app = express()
;
var bodyParser = require('body-parser');
// use it!
app.use(session({secret: '007mi6'}));
//session
app.use(bodyParser.urlencoded({ extended: true }));
// static content
app.use(express.static(path.join(__dirname, "./static")));
// setting up ejs and our views folder
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
// root route to render the index.ejs view
app.get('/', function(req, res) {
    req.session.num = Math.floor(Math.random()*100);
    console.log("number", req.session.num);
 res.render("index");
})
// Generating random number
app.post('/guess', function(req, res) {
 console.log("POST DATA", req.body);
 if (Number(req.body.guess) > req.session.num){
     var status = "high";
 }
 else if (Number(req.body.guess) < req.session.num){
     var status = "low";
 }
 else if (Number(req.body.guess) == req.session.num){
     var status = "correct";
 }
 // This is where the guessing logic goes
 // Then redirect to the root route
 console.log(status);
 res.render('result', {status:status});
})
// tell the express app to listen on port 8000
app.listen(8000, function() {
 console.log("listening on port 8000");
});
