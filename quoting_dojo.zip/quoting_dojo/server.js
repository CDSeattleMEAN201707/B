var express = require('express');
var app = express();

var mongoose = require('mongoose');

var QuoteSchema = new mongoose.Schema({
    author: {type: String, required: true, minlength: 1},
    text: {type: String, required: true, minlength: 1},
},  {timestamps: true});

mongoose.connect('mongodb://localhost/quoting_dojo');
mongoose.model('Quote', QuoteSchema);

var Quote = mongoose.model('Quote');

mongoose.Promise = global.Promise;

var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));

// PATH
var path = require('path');
// STATIC
app.use(express.static(path.join(__dirname, './static')));
// VIEWS
app.set('views', path.join(__dirname, './views'));
// VIEW ENGINE EJS
app.set('view engine', 'ejs');

// ROUTES
app.get('/', function(request, response) {

    return response.render('index');
});

app.get('/quotes', function(request, response) {

    Quote.find({}, function(error, results) {
        if( error ) { console.error( error ); }

        return response.render('quotes', {quotes: results});
    });
});

app.post('/quotes', function(request, response) {
    var post = request.body;

    var quote = new Quote();

        quote.author = post.author;
        quote.text = post.text;

    quote.save(function(error) {
        if( error ) {
            response.send("ERROR!\n" + error);
        } else {
            response.redirect('/quotes');
        }
    });
});

// PORT
app.listen(8000, function() {
    console.log("listening on port 8000");
})
