var express = require('express');
var app = express();
//------------------------------------------------------------
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
//------------------------------------------------------------

// PATH
var path = require('path');
// STATIC
app.use(express.static(path.join(__dirname, './static')));
// VIEWS
app.set('views', path.join(__dirname, './views'));
// VIEW ENGINE EJS
app.set('view engine', 'ejs');
//------------------------------------------------------------

// ROUTES

app.get('/', function(request, response) {

    return response.render('index');
});
//------------------------------------------------------------

// PORT

var server = app. listen(8000, function() {
    console.log( "listening on port 8000");
});


// SOCKETS

var io = require('socket.io').listen(server);
var chats = [];

io.sockets.on('connection', function(socket){
    console.log('THESE IS SOCKETS!');
    console.log(socket.id);

    socket. on('new_user', function(data){
        console.log("new user");
        console.log(data.name);
        socket. emit('server_response', {chats: chats});
    });

    socket. on('new_message', function(data){
        console.log(data.name);
        console.log(data.chat);
        chats.push({name:data.name, message:data.chat})
        io. emit('chat_update', {chats: chats});
    });
})
