
var express = require('express');
var app = express();
//------------------------------------------------------------
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
//------------------------------------------------------------

// PATH
var path = require('path');
// STATIC
app.use(express.static(path.join(__dirname, './static')));
// VIEWS
app.set('views', path.join(__dirname, './views'));
// VIEW ENGINE EJS
app.set('view engine', 'ejs');
//------------------------------------------------------------

// MONGOOSE

var mongoose = require('mongoose');
mongoose.Promise = global.Promise;

mongoose.connect('mongodb://localhost/ninja_dash');

var NinjaSchema = new mongoose.Schema({
    name: {type: String, required: true, minlength: 3},
    description: {type: String, required: true, minlength: 4},
},  {timestamps: true});

mongoose.model('Ninja', NinjaSchema);
var Ninja = mongoose.model('Ninja');
//------------------------------------------------------------

// ROUTES


app.get('/', function(req, res){
    Ninja.find({}, function(err, ninjas){
        if (err) {
            console.log(err)
            res.render('index')
        }
        if (ninjas) {
            console.log(ninjas)
            res.render('index', {ninjas: ninjas})
        }
    });
});

app.get('/ninjas/new', function(req, res){
    res.render('new_ninja')
});

app.get('/ninjas/:id', function(req, res){
    Ninja.findOne({_id:req.params.id}, function(err, ninjas){
        if (err) {
            console.log(req.params.id)
            console.log(err)
            res.render('index')
        }
        if (ninjas) {
            console.log(req.params.id)
            console.log(ninjas)
            res.render('one_ninja', {ninjas: ninjas})
        }
    })
})


app.post('/ninjas', function(req, res){
    console.log("POST DATA", req.body);
    var ninja = new Ninja({name: req.body.name, description: req.body.description});
    console.log(ninja)
    ninja.save(function(err){
        if (err) {
            console.log(" NEW NINJA NO WORK ")
            res.render('new_ninja', {title: 'ERROR!', errors: ninja.errors})
        } else {
            console.log(" NEW NINJA DEF WORK")
            res.redirect('/')
        }
    })
});

app.get('/ninjas/edit/:id', function(req, res){
    Ninja.findOne({_id:req.params.id}, function(err, ninjas){
        if (err) {
            console.log(err)
            res.render('index')
        }
        if (ninjas) {
            console.log(req.params.id)
            console.log(ninjas)
            res.render('edit_ninja', {ninjas: ninjas})
        }
    })
});

app.post('/ninjas/:id', function(req, res){
    console.log("POST DATA", req.body);
    console.log(req.params.id)
    Ninja.update({_id:req.params.id}, { $set: {name: req.body.name, description: req.body.description}}, function(err){
        console.log(err);
    })
    res.redirect('/')
})

app.post('/ninjas/destroy/:id', function(req, res){
    console.log(req.params.id)
    Ninja.remove({_id: req.params.id}, function(err){
        console.log(err);
    })
    res.redirect('/')
})
//------------------------------------------------------------

// PORT

app.listen(8000, function() {
    console.log("listening on port 8000");
})
